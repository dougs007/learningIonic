
export class Produtos {
    nome: string
    preco: string
    foto: string
    codigoBarra: {}
}
